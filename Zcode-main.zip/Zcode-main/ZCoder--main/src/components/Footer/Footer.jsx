



import React from 'react'
import Toggle from '../Toggle/Toggle'
import './Footer.css'
const Footer = () => {
  return (
    <div className="footer">
      <p>Copyrights &copy; Zcoder. All rights reserved</p>
    </div>
  )
}

export default Footer
