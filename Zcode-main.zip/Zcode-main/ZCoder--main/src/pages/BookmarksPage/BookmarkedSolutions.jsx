import React from 'react'

const BookmarkedSolutions = () => {
  return (
    <div>
      
    </div>
  )
}

export default BookmarkedSolutions
