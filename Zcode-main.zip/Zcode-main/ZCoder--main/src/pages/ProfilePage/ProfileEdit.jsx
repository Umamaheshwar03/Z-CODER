// import React from 'react'
// import { useState } from 'react'
// import { useAuthContext } from '../../hooks/useAuthContext'

// const ProfileEdit = () => {
//   const {userLogin} = useAuthContext()
//   const [updateUser,setUpdateUser] = useState({
//     userId:`${userLogin.data._id}`,
//     username:`${userLogin.data.username}`,
//     dob: "", // date of birth
//     techStack: "", // tech stack
//     languages: "" // languages known
//   })
//   return (
//     <div>
      
//     </div>
//   )
// }

// export default ProfileEdit
